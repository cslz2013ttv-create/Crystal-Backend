import { Document, Schema, model } from "mongoose";

export interface IUser extends Document {
  created: Date;
  banned: boolean;
  accountId: string;
  username: string;
  email: string;
  password: string;
  Role: string;
}

const UserSchema: Schema<IUser> = new Schema(
  {
    created: { type: Date, required: false },
    banned: { type: Boolean, default: false },
    accountId: { type: String, required: true, unique: true },
    Role: { type: String, required: false, unique: false },
    username: { type: String, required: true, unique: true },
    email: { type: String, required: false, unique: true },
    password: { type: String, required: false },
  },
  {
    collection: "users",
  }
);

const User = model<IUser>("Users", UserSchema);

export default User;
