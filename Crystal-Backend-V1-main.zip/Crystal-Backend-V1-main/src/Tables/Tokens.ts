import { Schema, Document, model } from "mongoose";

interface Tokens extends Document {
  accountId: string;
  type: string;
  token: string;
  permissions: any;
}

const Tokens = new Schema<Tokens>({
  accountId: { type: String, required: true },
  type: { type: String, required: true },
  token: { type: String, required: true },
  permissions: { type: Array, required: true },
});

const TokensModel = model<Tokens>("Tokens", Tokens);

export default TokensModel;
