import app from "..";
import Profile from "../Tables/Profile";
import verifyAuth from "../Utilities/Verify";

export default function () {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/SetItemFavoriteStatusBatch",
    verifyAuth,
    async (c) => {
      try {
        const { profileId, rvn } = c.req.query();
        var profiles: any = await Profile.findOne({
          accountId: c.req.param("accountId"),
        });
        let profile = profiles?.profiles[profileId];
        if (!profile || !profiles) {
          return c.json({
            profileRevision: 0,
            profileId: profileId,
            profileChangesBaseRevision: 0,
            profileChanges: [],
            profileCommandRevision: 0,
            serverTime: new Date().toISOString(),
            multiUpdate: [],
            responseVersion: 1,
          });
        }

        let BaseRevision = profile.rvn;
        let MultiUpdate: any = [];
        let ApplyProfileChanges: any = [];

        const body = await c.req.json();

        for (const item in body.itemIds) {
          profile.items[body.itemIds[item]].attributes.favorite = body.itemFavStatus[item];

          ApplyProfileChanges.push({
            changeType: "itemAttrChanged",
            itemId: body.itemIds[item],
            attributeName: "favorite",
            attributeValue: profile.items[body.itemIds[item]].attributes.favorite,
          });
        }

        profile.rvn += 1;
        profile.commandRevision += 1;
        profile.updated = new Date().toISOString();

        ApplyProfileChanges = [
          {
            changeType: "fullProfileUpdate",
            profile: profile,
          },
        ];

        await profiles.updateOne({
          $set: { [`profiles.${profileId}`]: profile },
        });

        return c.json({
          profileRevision: profile.rvn || 0,
          profileId: profileId,
          profileChangesBaseRevision: BaseRevision,
          profileChanges: ApplyProfileChanges,
          profileCommandRevision: profile.rvn,
          serverTime: new Date().toISOString(),
          multiUpdate: MultiUpdate,
          responseVersion: 1,
        });
      } catch (error) {
        console.error(error);
      }
    },
  );
}
