import app from "..";
import Profile from "../Tables/Profile";
import { applyProfileChanges } from "ares-library";
import verifyAuth from "../Utilities/Verify";

export default function () {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/RemoveGiftBox",
    verifyAuth,
    async (c) => {
      try {
        const { profileId, rvn } = c.req.query();
        var profiles: any = await Profile.findOne({
          accountId: c.req.param("accountId"),
        });
        let profile = profiles?.profiles[profileId];
        if (!profile || !profiles) {
          return c.json({
            profileRevision: 0,
            profileId: profileId,
            profileChangesBaseRevision: 0,
            profileChanges: [],
            profileCommandRevision: 0,
            serverTime: new Date().toISOString(),
            multiUpdate: [],
            responseVersion: 1,
          });
        }

        const body = await c.req.json();

        if (body.giftBoxItemIds) {
          delete profile.items[body.giftBoxItemIds];
        }

        profile.rvn += 1;
        profile.commandRevision += 1;
        profile.updated = new Date().toISOString();

        const response = await applyProfileChanges(
          profile,
          profileId,
          profiles
        );

        return c.json(response);
      } catch (error) {
        console.error(error);
      }
    }
  );
}
