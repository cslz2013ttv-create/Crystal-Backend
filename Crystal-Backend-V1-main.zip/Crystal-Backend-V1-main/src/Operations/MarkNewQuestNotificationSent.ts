import app from "..";
import Profile from "../Tables/Profile";
import { applyProfileChanges } from "../Utilities/Managers/ProfileManager";
import verifyAuth from "../Utilities/Verify";

export default function () {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/MarkNewQuestNotificationSent",
    verifyAuth,
    async (c) => {
      try {
        const { profileId } = c.req.query();
        var profiles: any = await Profile.findOne({
          accountId: c.req.param("accountId"),
        });
        const body = await c.req.json();
        let profile = profiles?.profiles[profileId];
        if (!profile || !profiles) {
          return c.json({
            profileRevision: 0,
            profileId: profileId,
            profileChangesBaseRevision: 0,
            profileChanges: [],
            profileCommandRevision: 0,
            serverTime: new Date().toISOString(),
            multiUpdate: [],
            responseVersion: 1,
          });
        }

        if (!body) {
          return c.json({ error: "Missing body" });
        }
        let ApplyProfileChanges: any = [];
        var profileChanged = false;

        if (body.itemIds) {
          for (var i in body.itemIds) {
            var id = body.itemIds[i];

            profile.items[id].attributes.sent_new_notification = true;

            ApplyProfileChanges.push({
              changeType: "itemAttrChanged",
              itemId: id,
              attributeName: "sent_new_notification",
              attributeValue: true,
            });

            profileChanged = true;
          }
        }

        const response = await applyProfileChanges(profile, profileId, profiles);

        return c.json(response);
      } catch (error) {
        console.error(error);
      }
    },
  );
}
