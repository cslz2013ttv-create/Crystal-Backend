import app from "..";
import Profile from "../Tables/Profile";
import path from "path";
import fs from "fs";
import { v4 } from "uuid";
import verifyAuth from "../Utilities/Verify";
import { applyProfileChanges } from "ares-library";

export default function () {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/ClientQuestLogin",
    verifyAuth,
    async (c) => {
      const profiles: any = await Profile.findOne({
        accountId: c.req.param("accountId"),
      });
      const profileId: any = c.req.query("profileId");
      let profile = profiles?.profiles[profileId];

      profile.rvn += 1;
      profile.commandRevision += 1;
      profile.updated = new Date().toISOString();

      const response = await applyProfileChanges(profile, profileId, profiles);

      return c.json(response);
    }
  );
}
