import app from "..";
import Profile from "../Tables/Profile";
import { v4 as uuiv4 } from "uuid";
import fs from "fs";
import path from "path";
import verifyAuth from "../Utilities/Verify";

export default function () {
  app.post(
    "/fortnite/api/game/v2/profile/:accountId/client/PurchaseCatalogEntry",
    verifyAuth,
    async (c) => {
      let { profileId, rvn } = c.req.query();
      var profiles = await Profile.findOne({
        accountId: c.req.param("accountId"),
      });
      let profile = profiles?.profiles["athena"];
      let common_core = profiles?.profiles["common_core"];
      let main = profiles?.profiles[profileId];
      if (!profile || !profiles || !common_core) {
        return c.json({
          profileRevision: 0,
          profileId: profileId,
          profileChangesBaseRevision: 0,
          profileChanges: [],
          profileCommandRevision: 0,
          serverTime: new Date().toISOString(),
          multiUpdate: [],
          responseVersion: 1,
        });
      }

      let BaseRevision = profile.rvn;
      let MultiUpdate: object[] = [];
      let ApplyProfileChanges: object[] = [];
      let notification: any = [];

      let shouldUpdateProfile = false;

      const body = await c.req.json();
      const { offerId, currency, purchaseQuantity } = body;

      // console.log(body);

      if (!offerId || !currency || !purchaseQuantity) {
        return c.json({
          error: "Invalid offerId, currency, or purchaseQuantity",
        });
      }

      if (purchaseQuantity < 1) {
        return c.json({
          error: "Invalid purchaseQuantity",
        });
      }

      const catalog = await Bun.file(
        path.join(__dirname, "..", "local", "storefront", "catalog.json")
      ).json();

      let owned = false;

      const currentShop = catalog;

      if (offerId.includes("Athena")) {
        notification.push({
          type: "CatalogPurchase",
          primary: true,
          lootResult: {
            items: [],
          },
        });

        let currentActiveStorefront = null;
        for (const section of currentShop.storefronts) {
          const found = section.catalogEntries.find(
            (entry: any) => entry.offerId === offerId
          );
          if (found) {
            currentActiveStorefront = found;
            break;
          }
        }

        if (!currentActiveStorefront) {
          return c.json({
            error: "Invalid offerId",
          });
        }

        if (purchaseQuantity < 1) {
          return c.json({
            error: "Invalid purchaseQuantity",
          });
        }

        if (
          !owned &&
          currentActiveStorefront.prices[0].finalPrice >
            common_core.items["Currency:MtxPurchased"].quantity
        ) {
          return c.json({
            error: "You do not have enough currency to purchase this item.",
          });
        }

        const alreadyOwned = currentActiveStorefront.itemGrants.some(
          (item: any) => profile.items[item.templateId]
        );
        if (alreadyOwned) {
          return c.json({ error: "You already own this item." });
        }

        const itemQuantitiesByTemplateId = new Map();
        const itemProfilesByTemplateId = new Map();

        for (const grant of currentActiveStorefront.itemGrants) {
          if (itemQuantitiesByTemplateId.has(grant.templateId)) {
            itemQuantitiesByTemplateId.set(
              grant.templateId,
              itemQuantitiesByTemplateId.get(grant.templateId) + grant.quantity
            );
          } else {
            itemQuantitiesByTemplateId.set(grant.templateId, grant.quantity);
          }
          if (!itemProfilesByTemplateId.has(grant.templateId)) {
            itemProfilesByTemplateId.set(grant.templateId, "athena");
          }
        }

        itemQuantitiesByTemplateId.forEach((quantity, templateId) => {
          profile.items[templateId] = {
            templateId,
            attributes: {
              level: 1,
              item_seen: false,
              xp: 0,
              variants: [],
              favorite: false,
            },
            quantity,
          };

          MultiUpdate.push({
            changeType: "itemAdded",
            itemId: templateId,
            item: profile.items[templateId],
          });

          notification[0].lootResult.items.push({
            itemType: templateId,
            itemGuid: templateId,
            itemProfile: "athena",
            quantity: 1,
          });
        });

        common_core.items["Currency:MtxPurchased"].quantity -=
          currentActiveStorefront.prices[0].finalPrice;

        MultiUpdate.push({
          changeType: "itemQuantityChanged",
          itemId: "Currency:MtxPurchased",
          quantity: common_core.items["Currency:MtxPurchased"].quantity,
        });

        const purchase = {
          purchaseId: uuiv4(),
          offerId: `v2:/${offerId}`,
          purchaseDate: new Date().toISOString(),
          undoTimeout: "9999-12-12T00:00:00.000Z",
          freeRefundEligible: false,
          fulfillments: [],
          lootResult: Object.keys(itemQuantitiesByTemplateId).map(
            (templateId) => ({
              itemType: templateId,
              itemGuid: templateId,
              itemProfile: "athena",
              quantity: itemQuantitiesByTemplateId.get(templateId),
            })
          ),
          totalMtxPaid: currentActiveStorefront.prices[0].finalPrice,
          metadata: {},
          gameContext: "",
        };

        common_core.stats.attributes.mtx_purchase_history!.purchases.push(
          purchase
        );
        owned = true;
        shouldUpdateProfile = true;
      } else if (
        offerId &&
        currency === "MtxCurrency" &&
        profileId === "common_core"
      ) {
        let battleCatalogEntry: any;

        const parsedCatalog = catalog.storefronts.find(
          (test: any) => test.name === `BRSeason${process.env.SEASON}`
        );

        const isValidOffer = parsedCatalog.catalogEntries.some((entry: any) => {
          if (entry.offerId === offerId) {
            battleCatalogEntry = entry;
            return true;
          }

          return false;
        });

        if (!isValidOffer || !battleCatalogEntry) {
          return c.json({
            error: "Invalid offerId",
          });
        }

        const currency = common_core.items["Currency:MtxPurchased"];
        const finalPrice = battleCatalogEntry.prices[0].finalPrice;

        if (typeof finalPrice !== "number") {
          return c.json({
            error: "Invalid finalPrice",
          });
        }

        let originalBookLevel = profile.stats.attributes.book_level;

        const isBattlepass =
          battleCatalogEntry.devName ===
          `BR.Season${process.env.SEASON}.BattlePass.01`;
        const isSingleTier = battleCatalogEntry.devName.includes("SingleTier");

        if (!profile.stats.attributes.book_purchased && isSingleTier) {
          return c.json({
            error: "You have not purchased the battlepass yet",
          });
        }

        if (currency.quantity < finalPrice) {
          return c.json({
            error: "You do not have enough currency to purchase this item",
          });
        }

        currency.quantity -= finalPrice;

        ApplyProfileChanges.push({
          changeType: "itemQuantityChanged",
          itemId: "Currency:MtxPurchased",
          quantity: currency.quantity,
        });

        profile.stats.attributes.book_purchased = true;

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "book_purchased",
          quantity: profile.stats.attributes.book_purchased,
        });

        if (isSingleTier) {
          let tierCount = profile.stats.attributes.book_level === 1 ? 2 : 1;
          let tierReward =
            profile.stats.attributes.book_level + tierCount * purchaseQuantity;
          const rewards = JSON.parse(
            fs.readFileSync(
              path.join(
                __dirname,
                "..",
                "local",
                "Season",
                `S${process.env.SEASON}`,
                "rewards.json"
              ),
              "utf-8"
            )
          );

          const giveRewards = rewards.filter(
            (reward: any) => reward.Tier <= tierReward
          );

          giveRewards.forEach((reward: any) => {
            profile.items[reward.Item] = {
              templateId: reward.Item,
              attributes: {
                level: 1,
                item_seen: false,
                xp: 0,
                variants: [],
                favorite: false,
              },
              quantity: reward.Quantity,
            };

            MultiUpdate.push({
              changeType: "itemAdded",
              itemId: reward.Item,
              item: profile.items[reward.Item],
            });

            notification.push({
              itemType: reward.Item,
              itemGuid: reward.Item,
              itemProfile: "athena",
              quantity: reward.Quantity,
            });
          });

          profile.stats.attributes.book_level = tierReward;
          profile.stats.attributes.level = tierReward;
          ApplyProfileChanges.push({
            changeType: "statModified",
            itemId: "book_level",
            value: profile.stats.attributes.book_level,
          });
        } else if (isBattlepass) {
          const tierCount = 1;

          const rewardsJsonPath = path.join(
            __dirname,
            "..",
            "local",
            "Season",
            `S${process.env.SEASON}`,
            "rewards.json"
          );

          const rewardsData = JSON.parse(
            fs.readFileSync(rewardsJsonPath, "utf-8")
          );

          const tierOneRewards = rewardsData.filter(
            (reward: any) => reward.Tier === 1
          );

          tierOneRewards.forEach((reward: any) => {
            profile.items[reward.Item] = {
              templateId: reward.Item,
              attributes: {
                level: 1,
                item_seen: false,
                xp: 0,
                variants: [],
                favorite: false,
              },
              quantity: reward.Quantity,
            };

            MultiUpdate.push({
              changeType: "itemAdded",
              itemId: reward.Item,
              item: profile.items[reward.Item],
            });
          });

          profile.stats.attributes.book_level = 1;
          profile.stats.attributes.level = 1;
          profile.stats.attributes.season_friend_match_boost += 60;
          profile.stats.attributes.season_match_boost += 50;

          // let ver: number = Number(process.env.SEASON);

          // const randomGiftBoxId = uuiv4();
          // const giftBoxTemplateId =
          //   ver >= 5 ? "GiftBox:gb_battlepasspurchased" : "GiftBox:gb_battlepass";

          // common_core.items[randomGiftBoxId] = {
          //   templateId: giftBoxTemplateId,
          //   attributes: {
          //     max_level_bonus: 0,
          //     fromAccountId: "Server",
          //     lootList: notification,
          //   },
          //   quantity: 1,
          // };

          // ApplyProfileChanges.push({
          //   changeType: "itemAdded",
          //   itemId: randomGiftBoxId,
          //   item: {
          //     templateId: giftBoxTemplateId,
          //     attributes: {
          //       max_level_bonus: 0,
          //       fromAccountId: "Server",
          //       lootList: notification,
          //     },
          //     quantity: 1,
          //   },
          //});

          ApplyProfileChanges.push({
            changeType: "statModified",
            itemId: "book_xp",
            value: profile.stats.attributes.book_xp,
          });

          ApplyProfileChanges.push({
            changeType: "statModified",
            itemId: "xp",
            value: profile.stats.attributes.xp,
          });
        }

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "book_level",
          value: profile.stats.attributes.book_level,
        });

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "level",
          value: profile.stats.attributes.level,
        });

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "level",
          value: profile.stats.attributes.level,
        });

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "battlestars",
          value: profile.stats.attributes.battlestars,
        });

        MultiUpdate.push({
          changeType: "statModified",
          itemId: "battlestars_season_total",
          value: profile.stats.attributes.battlestars_season_total,
        });

        MultiUpdate.push({
          changeType: "itemQuantityChanged",
          itemId: "Currency:MtxPurchased",
          quantity: currency.quantity,
        });

        if (profile.stats.attributes.book_level > 100) {
          profile.stats.attributes.book_level = 100;
        }

        if (profile.stats.attributes.level > 100) {
          profile.stats.attributes.level = 100;
        }

        owned = true;
        shouldUpdateProfile = true;
      }

      if (shouldUpdateProfile) {
        profile.rvn += 1;
        profile.commandRevision += 1;
        profile.updated = new Date().toISOString();

        common_core.rvn += 1;
        common_core.commandRevision += 1;
        common_core.updated = new Date().toISOString();

        await profiles.updateOne({
          $set: {
            [`profiles.athena`]: profile,
          },
        });
        await profiles.updateOne({
          $set: {
            [`profiles.common_core`]: common_core,
          },
        });
      }

      const profileRevision = profile.rvn;
      const queryRevision = parseInt(rvn) || 0;

      ApplyProfileChanges =
        queryRevision !== profileRevision
          ? [{ changeType: "fullProfileUpdate", profile: common_core }]
          : [];

      return c.json({
        profiileRevision: common_core.rvn,
        profileId,
        profileChangesBaseRevision: BaseRevision,
        profileChanges: ApplyProfileChanges,
        notifications: notification,
        profileCommandRevision: common_core.commandRevision,
        serverTime: new Date().toISOString(),
        multiUpdate: [
          {
            profileRevision: profile.rvn,
            profileId: "athena",
            profileChangesBaseRevision: profile.rvn - 1,
            profileChanges: MultiUpdate,
            profileCommandRevision: profile.commandRevision,
          },
        ],
        responseVersion: 1,
      });
    }
  );
}
