import { Hono } from "hono";
import { cors } from "hono/cors";
import { config } from "dotenv";
import mongoose from "mongoose";
import path from "path";
import loadRoutes from "./Utilities/Routing";
import logger from "./Utilities/Logger";

config({ path: path.join(__dirname, "../config/.env") });

const app = new Hono({ strict: false });
app.use(cors());

app.notFound(async (c) => {
  return c.json({
    errorCode: "errors.com.crystal.common.not_found",
    errorMessage:
      "Sorry the resource you were trying to find could not be found",
    numericErrorCode: 1004,
    originatingService: "fortnite",
    intent: "prod",
  });
});

export default app;

async function main() {
  const db = process.env.MONGO_URI || "mongodb://localhost:27017/flair";

  try {
    await mongoose.connect(db);
    logger.database("Connected to MongoDB");
  } catch (error) {
    logger.error(`Failed to connect to MongoDB`, error);
  }

  await loadRoutes.loadRoutes(path.join(__dirname, "routes"), app);
  await loadRoutes.loadRoutes(path.join(__dirname, "operations"), app);

  Bun.serve({
    port: 8080,
    fetch: app.fetch,
    idleTimeout: 60,
  });

  logger.backend("Crystal Running on port 443");
}

main().catch((err) => {
  console.error("Fatal error during startup:", err);
});
