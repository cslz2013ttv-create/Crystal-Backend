import type { PipelineStage } from "mongoose";
import app from "../..";
import User from "../../Tables/User";

export default function () {
  app.get("/v1/launcher/leaderboard", async (c) => {
    try {
      const pipeline: PipelineStage[] = [
        {
          $lookup: {
            from: "profiles",
            localField: "accountId",
            foreignField: "accountId",
            as: "profile",
          },
        },
        {
          $unwind: {
            path: "$profile",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $addFields: {
            hype: {
              $ifNull: [
                "$profile.profiles.athena.stats.attributes.arena_hype",
                0,
              ],
            },
          },
        },
        {
          $sort: { hype: -1 },
        },
        {
          $limit: 50,
        },
        {
          $project: {
            username: 1,
            hype: 1,
            _id: 0,
          },
        },
      ];

      const leaderboard = await User.aggregate(pipeline);
      c.header("Cache-Control", "public, max-age=300");
      return c.json(leaderboard);
    } catch (error) {
      return c.json({ error: "failed to fetch leaderboard?" }, 500);
    }
  });

  app.get("/v1/launcher/shop", async (c) => {
    const catalog: any = await Bun.file(
      "src/local/storefront/catalog.json"
    ).json();

    const storefrontItems = (storefrontName: string) => {
      const storefront = catalog.storefronts.find(
        (sf: any) => sf.name === storefrontName
      );
      if (!storefront || !storefront.catalogEntries) return [];

      return storefront.catalogEntries.map((entry: any) => {
        return {
          id: entry.devName || entry.offerId || "",
          price: entry.prices?.[0]?.finalPrice ?? 0,
        };
      });
    };

    const dailyItems = storefrontItems("BRDailyStorefront");
    const featuredItems = storefrontItems("BRWeeklyStorefront");

    return c.json({
      daily: dailyItems,
      featured: featuredItems,
    });
  });
}
