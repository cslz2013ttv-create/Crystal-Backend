import app from "../..";

export default function () {
  app.get("/fortnite/api/v2/versioncheck/Windows", async (c) => {
    return c.json({
      type: "NO_UPDATE",
    });
  });

  app.get("/waitingroom/api/waitingroom", async (c) => {
    return c.json([], 204);
  });

  app.get("/fortnite/api/v2/versioncheck/IOS", async (c) => {
    return c.json({
      type: "NO_UPDATE",
    });
  });

  app.get("/fortnite/api/game/v2/friendcodes/:accountid/epic", async (c) => {
    return c.json({});
  });

  app.post(
    "/fortnite/api/game/v2/chat/:accountId/recommendGeneralChatRooms/:gameType/pc",
    async (c) => {
      return c.json({
        globalChatRooms: [
          {
            roomName: "fortnite",
            currentMembersCount: 0,
            maxMembersCount: 9999,
            publicFacingShardName: "",
          },
        ],
        founderChatRooms: [
          {
            roomName: "founder",
            currentMembersCount: 0,
            maxMembersCount: 9999,
            publicFacingShardName: "",
          },
        ],
        bNeedsPaidAccessForGlobalChat: false,
        bNeedsPaidAccessForFounderChat: false,
        bIsGlobalChatDisabled: false,
        bIsFounderChatDisabled: false,
        bIsSubGameGlobalChatDisabled: false,
      });
    }
  );

  app.get("/epic/friends/v1/:accountId/blocklist", async (c) => {
    return c.json([]);
  });

  app.get("/launcher/api/public/distributionpoints", async (c) => {
    return c.json({
      distributions: [
        "https://download.epicgames.com/",
        "https://download2.epicgames.com/",
        "https://download3.epicgames.com/",
        "https://download4.epicgames.com/",
        "https://epicgames-download1.akamaized.net/",
      ],
    });
  });

  app.get(
    "/fortnite/api/receipts/v1/account/:accountid/receipts",
    async (c) => {
      return c.json({});
    }
  );

  app.get("/fortnite/api/entitlementCheck", async (c) => {
    return c.json([], 204);
  });

  app.get("/waitingroom/api/waitingroom", async (c) => {
    return c.json([]);
  });

  app.post("/datarouter/api/v1/public/data", async (c) => {
    return c.json([], 200);
  });

  app.post("/fortnite/api/game/v2/tryPlayOnPlatform/account/*", async (c) => {
    c.header("Content-Type", "text/plain");
    return c.text("true");
  });

  app.get("/fortnite/api/game/v2/enabled_features", async (c) => {
    return c.json([]);
  });

  app.post("/fortnite/api/game/v2/grant_access/*", async (c) => {
    c.json({});
    return c.json([], 204);
  });
}
