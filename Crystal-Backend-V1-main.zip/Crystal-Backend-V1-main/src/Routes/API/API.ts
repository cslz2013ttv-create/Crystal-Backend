import app from "../../index.ts";
import Profile from "../../Tables/Profile.ts";

export default function () {
  app.get("/fortnite/api/game/v2/br-inventory/account/*", async (c) => {
    var profiles: any = await Profile.findOne({
      accountId: c.req.param("accountId"),
    });
    let profile = profiles?.profiles["athena"];

    if (!profile || !profiles) {
      return c.json({
        error: "Profile not found",
      });
    }

    profile.stats.attributes.globalCash =
      profile.stats.attributes.globalCash.quantity;
    return c.json({
      stash: {
        globalcash: profile.stats.attributes.globalCash.quantity,
      },
    });
  });

  app.get("/unknown", async (c) => {
    return c.json([], 404);
  });
}
