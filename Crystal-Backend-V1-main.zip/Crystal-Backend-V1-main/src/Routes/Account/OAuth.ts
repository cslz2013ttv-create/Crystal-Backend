import User from "../../Tables/User.ts";
import app from "../../index.ts";
import { v4 as uuidv4 } from "uuid";
import { sign, verify, type JwtPayload } from "jsonwebtoken";
import TokensModel from "../../Tables/Tokens.ts";
import getVersion from "../../Utilities/getVersion.ts";
import crypto from "crypto";
import path from "path";
import { config } from "dotenv";
import TokenUtilities from "../../Utilities/Tokens/Tokens.ts";

config({ path: path.join(__dirname, "../../../config/.env") });

const CLIENT_SECRET =
  process.env.CLIENT_SECRET ||
  (() => {
    throw new Error("CLIENT_SECRET environment variable is required");
  })();

export function validateBase64(input: string) {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

export default function () {
  app.post("/account/api/oauth/token", async (c) => {
    const tokenHeader = c.req.header("Authorization");
    const uahelper = getVersion(c);

    if (!tokenHeader) {
      console.log("Missing Authorization header");
      return c.json({ error: "Missing Authorization header" }, 400);
    }

    const token = tokenHeader.split(" ");

    if (token.length !== 2 || !validateBase64(token[1])) {
      console.log("Invalid base64 token");
      return c.json({ error: "Invalid base64 token" }, 400);
    }

    let body;

    try {
      body = await c.req.parseBody();
    } catch (error) {
      console.log("Failed to parse body");
      return c.json({ error: "Failed to parse body" }, 400);
    }

    if (!uahelper) {
      return c.json({ error: "Missing or invalid User-Agent header" }, 400);
    }

    let { grant_type: grantType } = body;

    const clientId: string = Buffer.from(token[1], "base64")
      .toString()
      .split(":")[0];

    if (!clientId) {
      return c.json({ error: "Invalid client_id" }, 400);
    }

    if (!grantType) {
      return c.json({ error: "unsupported_grant_type" }, 400);
    }

    let user = null;

    const now = new Date();
    const expires_in = 3600;
    const expires_at = new Date(now.getTime() + expires_in * 1000);
    const device_id = c.req.header("X-Epic-Device-Id") || uuidv4();

    console.log(grantType);

    switch (grantType) {
      case "client_credentials":
        const token = sign(
          {
            p: crypto.randomBytes(128).toString("base64"),
            clsvc: "fortnite",
            t: "s",
            mver: false,
            clid: clientId,
            ic: true,
            exp: Math.floor(Date.now() / 1000) + 240 * 240,
            am: "client_credentials",
            iat: Math.floor(Date.now() / 1000),
            jti: crypto.randomBytes(32).toString("hex"),
            creation_date: new Date().toISOString(),
            expires_in: 1,
          },
          CLIENT_SECRET.toString()
        );

        return c.json({
          access_token: `eg1~${token}`,
          expires_in: 3600,
          expires_at: new Date(Date.now() + 3600 * 1000).toISOString(),
          token_type: "bearer",
          client_id: clientId,
          internal_client: true,
          client_service: "fortnite",
        });

      case "refresh_token":
        const { refresh_token } = body;

        if (!refresh_token)
          return c.json(
            { error: "Missing refresh_token in request body" },
            400
          );

        const cleanedRefreshToken = refresh_token
          .toString()
          .replace("eg1~", "");

        const refreshTokenDoc = await TokensModel.findOne({
          token: cleanedRefreshToken,
        });
        if (!refreshTokenDoc)
          return c.json({ error: "Invalid Refresh Token." }, 400);

        user = await User.findOne({ accountId: refreshTokenDoc.accountId });
        if (!user) return c.json({ error: "Invalid Refresh Token." }, 400);

        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "accesstoken",
        });
        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "refreshtoken",
        });

        const accessToken = await TokenUtilities.createAccessToken(
          clientId,
          grantType as string,
          user
        );
        const refreshToken = await TokenUtilities.createRefreshToken(
          clientId,
          user
        );

        return c.json({
          access_token: accessToken,
          expires_in: 3600,
          expires_at: new Date(Date.now() + 3600 * 1000).toISOString(),
          token_type: "bearer",
          account_id: user.accountId,
          client_id: clientId,
          internal_client: true,
          client_service: "fortnite",
          refresh_token: refreshToken,
          refresh_expires: 86400,
          refresh_expires_at: new Date(Date.now() + 86400 * 1000).toISOString(),
          displayName: user.username,
          app: "fortnite",
          in_app_id: user.accountId,
          device_id: device_id,
        });

      case "password":
        const { username, password } = body;

        if (!password || !username)
          return c.json(
            { error: "Missing username or password in request body" },
            400
          );

        user = await User.findOne({ email: username });

        if (!user) return c.json({ error: "Invalid account credentials" }, 400);

        if (user.banned) return c.json({ error: "User is banned" }, 403);

        if (user.password !== password)
          return c.json({ error: "Invalid account credentials" }, 400);

        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "accesstoken",
        });
        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "refreshtoken",
        });

        const passwordAccessToken = await TokenUtilities.createAccessToken(
          clientId,
          grantType as string,
          user
        );
        const passwordRefreshToken = await TokenUtilities.createRefreshToken(
          clientId,
          user
        );

        return c.json({
          access_token: passwordAccessToken,
          expires_in: 3600,
          expires_at: new Date(Date.now() + 3600 * 1000).toISOString(),
          token_type: "bearer",
          account_id: user.accountId,
          client_id: clientId,
          internal_client: true,
          client_service: "fortnite",
          refresh_token: passwordRefreshToken,
          refresh_expires: 86400,
          refresh_expires_at: new Date(Date.now() + 86400 * 1000).toISOString(),
          displayName: user.username,
          app: "fortnite",
          in_app_id: user.accountId,
          device_id: device_id,
        });

      case "exchange_code":
        const { exchange_code: exchangeCode } = body;
        if (!exchangeCode)
          return c.json({ error: "exchange_code_required" }, 400);

        const validExchangeCode = await TokensModel.findOne({
          type: "exchange",
          token: exchangeCode,
        });
        if (!validExchangeCode)
          return c.json({ error: "Invalid exchange code" }, 400);

        user = await User.findOne({ accountId: validExchangeCode.accountId });
        if (!user || user.banned)
          return c.json({ error: "Invalid exchange code" }, 400);

        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "exchange",
        });

        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "accesstoken",
        });
        await TokensModel.deleteOne({
          accountId: user.accountId,
          type: "refreshtoken",
        });

        const exchangeAccessToken = await TokenUtilities.createAccessToken(
          clientId,
          grantType as string,
          user
        );
        const exchangeRefreshToken = await TokenUtilities.createRefreshToken(
          clientId,
          user
        );

        return c.json({
          access_token: exchangeAccessToken,
          expires_in: 3600,
          expires_at: new Date(Date.now() + 3600 * 1000).toISOString(),
          token_type: "bearer",
          account_id: user.accountId,
          client_id: clientId,
          internal_client: true,
          client_service: "fortnite",
          refresh_token: exchangeRefreshToken,
          refresh_expires: 86400,
          refresh_expires_at: new Date(Date.now() + 86400 * 1000).toISOString(),
          displayName: user.username,
          app: "fortnite",
          in_app_id: user.accountId,
          device_id: device_id,
        });

      default:
        console.log("grant_type_not_implemented");
        return c.json({ error: "grant_type_not_implemented" }, 400);
    }
  });

  app.delete("/account/api/oauth/sessions/kill/:token", async (c) => {
    const token = c.req.param("token");
    const Authorization = c.req.header("Authorization");

    if (!token) return c.json({ error: "Missing token parameter" }, 400);
    if (!Authorization)
      return c.json({ error: "Missing Authorization header" }, 400);

    try {
      const decodedToken = verify(
        token.replace("eg1~", ""),
        CLIENT_SECRET.toString()
      ) as JwtPayload;

      if (typeof decodedToken === "string" || !decodedToken)
        return c.json({ error: "Invalid token" }, 400);

      const user = await User.findOne({ accountId: decodedToken.sub });

      if (!user) return c.json({ error: "Invalid token" }, 400);

      await TokensModel.deleteOne({
        accountId: user.accountId,
        type: "accesstoken",
      });
      await TokensModel.deleteOne({
        accountId: user.accountId,
        type: "refreshtoken",
      });

      return c.body(null, 204);
    } catch (error) {
      return c.json({ error: "Invalid token" }, 400);
    }
  });

  app.delete("/account/api/oauth/sessions/kill", async (c) => {
    return c.body(null, 204);
  });

  app.get("/account/api/oauth/verify", async (c) => {
    const authHeader = c.req.header("Authorization");
    if (!authHeader)
      return c.json({ error: "Missing Authorization header" }, 400);

    const token: string = authHeader.split("bearer ")[1] as string;
    if (!token)
      return c.json({ error: "Missing token in Authorization header" }, 400);

    const accessToken = token.replace("eg1~", "");

    try {
      const decodedToken = verify(
        accessToken,
        CLIENT_SECRET.toString()
      ) as JwtPayload;

      if (typeof decodedToken === "string" || !decodedToken)
        return c.json({ error: "Invalid token" }, 400);

      console.log(decodedToken);
      const user = await User.findOne({ accountId: decodedToken.sub });

      if (!user) return c.json({ error: "Invalid token" }, 400);

      const creationTime = new Date(decodedToken.creation_date);
      const expiry = new Date(
        creationTime.getTime() + decodedToken.expires_in * 60 * 60 * 1000
      );

      return c.json({
        token,
        session_id: decodedToken.jti,
        token_type: "bearer",
        client_id: decodedToken.clid,
        internal_client: true,
        client_service: "fortnite",
        account_id: user.accountId,
        expires_in: Math.round((expiry.getTime() - Date.now()) / 1000),
        expires_at: expiry.toISOString(),
        auth_method: decodedToken.am,
        display_name: user.username,
        app: "fortnite",
        in_app_id: user.accountId,
        device_id: decodedToken.dvid,
      });
    } catch (error) {
      return c.json({ error: "Invalid token" }, 400);
    }
  });
}
