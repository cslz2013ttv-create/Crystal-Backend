import app from "../..";
import Profile from "../../Tables/Profile";
import fs from "fs";
import path from "path";
import User from "../../Tables/User";
import { v4 } from "uuid";
import verifyAuth from "../../Utilities/Verify";

export default function () {
  app.get("/api/v1/events/Fortnite/download/:accountId", async (c) => {
    const profiles: any = await Profile.findOne({
      accountId: c.req.param("accountId"),
    });

    let profile = profiles?.profiles["athena"];
    if (!profile) {
      return c.json({ error: "Profile not found" }, 404);
    }
    const eventPage = JSON.parse(
      fs.readFileSync(path.join(__dirname, "../../local/events/event.json"), {
        encoding: "utf8",
      })
    );

    eventPage.events[0].announcementTime = new Date().toISOString();
    eventPage.events[0].beginTime = new Date().toISOString();

    if (
      typeof eventPage.player === "object" &&
      !Array.isArray(eventPage.player)
    ) {
      eventPage.player.accountId = profiles.accountId;
      eventPage.player.persistentScores = {
        NormalHype: profile.stats.attributes.arena_hype ?? 0,
      };
      const division = profile.stats.attributes.division;
      if (division != null) {
        eventPage.player.tokens = Array.isArray(division)
          ? division
          : [division];
      } else {
        eventPage.player.tokens = ["NormalArenaDiv1"];
      }
    } else {
      console.error("eventPage.player is not an object");
    }

    return c.json(eventPage);
  });
}
