import app from "../..";
import getVersion from "../../Utilities/getVersion";

export default function () {
  app.get("/content/api/pages/fortnite-game", async (c) => {
    const ver = getVersion(c);

    const content = {
      _title: "Fortnite Game",
      _activeDate: "2017-08-30T03:20:48.050Z",
      lastModified: "2019-11-01T17:33:35.346Z",
      _locale: "en-US",
      tournamentinformation: {
        _activeDate: new Date().toISOString(),
        _locale: "en-US",
        _templateName: "FortniteGameTournamentInfo",
        _title: "tournamentinformation",
        conversion_config: {
          _type: "Conversion Config",
          containerName: "tournament_info",
          contentName: "tournaments",
          enableReferences: true,
        },
        lastModified: "0001-01-01T00:00:00",
        tournament_info: {
          _type: "Tournaments Info",
          tournaments: [
            {
              _type: "Tournament Display Info",
              loading_screen_image:
                "https://cdn.projecthelix.website/Arena_Playlist.png",
              playlist_tile_image:
                "https://cdn.projecthelix.website/Arena_Playlist.png",
              title_line_1: "LATEGAME ARENA",
              title_line_2: null,
              tournament_display_id: "ARENA_SOLO",
            },
          ],
        },
      },
      playlistinformation: {
        frontend_matchmaking_header_style: "None",
        _title: "playlistinformation",
        frontend_matchmaking_header_text: "",
        playlist_info: {
          _type: "Playlist Information",
          playlists: [
            {
              image: `https://overseasoverseasbackend.xyz/S${ver}Solo.jpg`,
              playlist_name: "Playlist_DefaultSolo",
              hidden: false,
              special_border: "None",
              _type: "FortPlaylistInfo",
            },
            {
              image:
                "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlistinformation/CM_LobbyTileArt-1024x512-fbcd48db36552ccb1ab4021b722ea29d515377cc.jpg",
              playlist_name: "Playlist_PlaygroundV2",
              hidden: false,
              special_border: "None",
              _type: "FortPlaylistInfo",
            },
            {
              image: `https://overseasoverseasbackend.xyz/S${ver}Duo.png`,
              playlist_name: "Playlist_DefaultDuo",
              hidden: false,
              special_border: "None",
              _type: "FortPlaylistInfo",
            },
            {
              image: `https://overseasoverseasbackend.xyz/S${ver}Squad.png`,
              playlist_name: "Playlist_DefaultSquad",
              hidden: false,
              special_border: "None",
              _type: "FortPlaylistInfo",
            },
          ],
        },
        _noIndex: false,
        _activeDate: new Date().toISOString(),
        lastModified: new Date().toISOString(),
        _locale: "en-US",
      },
      playlistimages: {
        playlistimages: {
          images: [
            {
              image: `https://cdn.projecthelix.website/S15Solo.png`,
              _type: "PlaylistImageEntry",
              playlistname: "Playlist_DefaultSolo",
            },
            {
              image:
                "https://cdn2.unrealengine.com/Fortnite/fortnite-game/playlistinformation/CM_LobbyTileArt-1024x512-fbcd48db36552ccb1ab4021b722ea29d515377cc.jpg",
              playlistname: "Playlist_PlaygroundV2",
              _type: "PlaylistImageEntry",
            },
            {
              image: `https://cdn.projecthelix.website/S15Duo.png`,
              _type: "PlaylistImageEntry",
              playlistname: "Playlist_DefaultDuo",
            },
            {
              image: `https://overseasoverseasbackend.xyz/S${ver}Squad.png`,
              _type: "PlaylistImageEntry",
              playlistname: "Playlist_DefaultSquad",
            },
          ],
          _type: "PlaylistImageList",
        },
        _title: "playlistimages",
        _activeDate: new Date().toISOString(),
        lastModified: new Date().toISOString(),
        _locale: "en-US",
      },
      emergencynotice: {
        news: {
          _type: "Battle Royale News",
          messages: [
            {
              hidden: false,
              _type: "CommonUI Simple Message Base",
              title: "Crystal",
              body: "Servers are currently experiencing issues. For more information, visit #status in our discord.",
              spotlight: true,
            },
          ],
        },
        _title: "emergencynotice",
        _noIndex: false,
        alwaysShow: false,
        _activeDate: "2018-08-06T19:00:26.217Z",
        lastModified: "2019-10-29T22:32:52.686Z",
        _locale: "en-US",
      },
      emergencynoticev2: {
        "jcr:isCheckedOut": true,
        _title: "emergencynoticev2",
        _noIndex: false,
        "jcr:baseVersion": "a7ca237317f1e771e921e2-7f15-4485-b2e2-553b809fa363",
        emergencynotices: {
          _type: "Emergency Notices",
          emergencynotices: [
            {
              gamemodes: [],
              hidden: false,
              _type: "CommonUI Emergency Notice Base",
              title: "Crystal",
              body: "Servers are currently experiencing issues. For more information, visit #status in our discord.",
            },
          ],
        },
        _activeDate: "2018-08-06T19:00:26.217Z",
        lastModified: "2021-12-01T15:55:56.012Z",
        _locale: "en-US",
      },
      lobby: {
        stage: `season${ver}`,
        _title: "lobby",
        _activeDate: "2019-05-31T21:24:39.892Z",
        lastModified: "2019-07-31T21:24:17.119Z",
        _locale: "en-US",
      },
      battleroyalenewsv2: {
        alwaysShow: true,
        lastModified: "0000-00-00T00:00:00.000Z",
        news: {
          motds: [
            {
              id: "news2",
              entryType: "Website",
              image: "https://cdn.projecthelix.website/donatenewssize.png",
              tileImage: "https://cdn.projecthelix.website/donatenews.png",
              hidden: false,
              title: "DONATIONS",
              body: "You can now donate to Crystal! Get Full Locker, Starter Pack, or OG Pack.",
              sortingPriority: -1,
              spotlight: false,
              websiteButtonText: "Donate",
              websiteURL: "https://crystalmp.mysellauth.com/",
            },
          ],
        },
      },
      dynamicbackgrounds: {
        backgrounds: {
          backgrounds: [
            { stage: `Galileo`, _type: "DynamicBackground", key: "lobby" },
          ],
          _type: "DynamicBackgroundList",
        },
        _title: "dynamicbackgrounds",
        _noIndex: false,
        _activeDate: "2019-08-21T15:59:59.342Z",
        lastModified: "2019-10-29T13:07:27.936Z",
        _locale: "en-US",
        _templateName: "FortniteGameDynamicBackgrounds",
      },
      shopSections: {
        _title: "shop-sections",
        sectionList: {
          _type: "ShopSectionList",
          sections: [
            {
              bSortOffersByOwnership: false,
              bShowIneligibleOffersIfGiftable: false,
              bEnableToastNotification: true,
              background: {
                stage: "default",
                _type: "DynamicBackground",
                key: "vault",
              },
              _type: "ShopSection",
              landingPriority: 70,
              bHidden: false,
              sectionId: "Featured",
              bShowTimer: true,
              sectionDisplayName: "Featured",
              bShowIneligibleOffers: true,
            },
            {
              bSortOffersByOwnership: false,
              bShowIneligibleOffersIfGiftable: false,
              bEnableToastNotification: true,
              background: {
                stage: "default",
                _type: "DynamicBackground",
                key: "vault",
              },
              _type: "ShopSection",
              landingPriority: 70,
              bHidden: false,
              sectionId: "Daily",
              bShowTimer: false,
              sectionDisplayName: "Daily",
              bShowIneligibleOffers: true,
            },
          ],
        },
        _noIndex: false,
        _activeDate: "2022-12-01T23:45:00.000Z",
        lastModified: "2022-12-01T21:50:44.089Z",
        _locale: "en-US",
        _templateName: "FortniteGameShopSections",
      },
      _suggestedPrefetch: [],
    };

    return c.json(content);
  });
}
