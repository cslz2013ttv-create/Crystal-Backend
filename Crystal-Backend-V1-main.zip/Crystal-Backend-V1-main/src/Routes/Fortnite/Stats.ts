import app from "../..";
import Profile from "../../Tables/Profile";
import User from "../../Tables/User";

// old asf
export default function () {
  app.get("/fortnite/api/statsv2/account/:accountId", async (c) => {
    const user = await User.findOne({ accountId: c.req.param("accountId") });
    const profiles = await Profile.findOne({
      accountId: c.req.param("accountId"),
    });
    if (!profiles) {
      return c.json({ error: "No profiles found" });
    }

    let profile = profiles?.profiles["athena"];

    const statResponse = {
      br_score_keyboardmouse_m0_playlist_DefaultSolo:
        profile.stats.attributes.accountLevel,
      br_kills_keyboardmouse_m0_playlist_DefaultSolo:
        profile.stats.attributes.solo.solo_kills,
      br_playersoutlived_keyboardmouse_m0_playlist_DefaultSolo: 0,
      br_matchesplayed_keyboardmouse_m0_playlist_DefaultSolo:
        profile.stats.attributes.solo.solo_matches,
      br_placetop25_keyboardmouse_m0_playlist_DefaultSolo: 0,
      br_placetop1_keyboardmouse_m0_playlist_DefaultSolo:
        profile.stats.attributes.solo.solo_wins,

      br_score_keyboardmouse_m0_playlist_DefaultDuo: 0,
      br_kills_keyboardmouse_m0_playlist_DefaultDuo:
        profile.stats.attributes.duo.duo_kills,
      br_playersoutlived_keyboardmouse_m0_playlist_DefaultDuo: 0,
      br_matchesplayed_keyboardmouse_m0_playlist_DefaultDuo:
        profile.stats.attributes.duo.duo_matches,
      br_placetop25_keyboardmouse_m0_playlist_DefaultDuo: 0,
      br_placetop1_keyboardmouse_m0_playlist_DefaultDuo:
        profile.stats.attributes.duo.duo_wins,

      br_score_keyboardmouse_m0_playlist_DefaultSquad: 0,
      br_kills_keyboardmouse_m0_playlist_DefaultSquad:
        profile.stats.attributes.squad.squad_kills,
      br_playersoutlived_keyboardmouse_m0_playlist_DefaultSquad: 0,
      br_matchesplayed_keyboardmouse_m0_playlist_DefaultSquad:
        profile.stats.attributes.squad.squad_matches,
      br_placetop25_keyboardmouse_m0_playlist_DefaultSquad: 0,
      br_placetop1_keyboardmouse_m0_playlist_DefaultSquad:
        profile.stats.attributes.squad.squad_wins,
    };

    return c.json({
      startTime: user?.created,
      endTime: new Date().toISOString(),
      stats: statResponse,
      accountId: user?.accountId,
    });
  });
}
