import { v4 as uuidv4 } from "uuid";
import type { Context } from "hono";
import app from "../..";
import User from "../../Tables/User";
import verifyAuth from "../../Utilities/Verify";

// removed all my mm, sorry gangster

export default function () {
  app.get(
    "/fortnite/api/matchmaking/session/findPlayer/*",
    async (c: Context) => {
      return c.text("", 200);
    }
  );

  app.get(
    "/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId",
    verifyAuth,
    async (c) => {
      const user = await User.findOne({ accountId: c.req.param("accountId") });

      if (user?.banned == true) {
        return c.json({ error: "User is banned!" }, 404);
      }

      return c.json({
        serviceUrl: `ws://127.0.0.1:80`,
        ticketType: "nuhuh",
        payload: "dsasdasd",
        signature: "asdasd",
      });
    }
  );

  app.get(
    "/fortnite/api/game/v2/matchmaking/account/:accountId/session/:sessionId",
    verifyAuth,
    async (c: Context) => {
      const { accountId, sessionId } = c.req.param();
      return c.json({
        accountId: accountId,
        sessionId: sessionId,
        key: "AOJEv8uTFmUh7XM2328kq9rlAzeQ5xzWzPIiyKn2s7s=",
      });
    }
  );

  app.get("/fortnite/api/matchmaking/session/:sessionId", async (c) => {
    let serverAddress;
    let serverPort;
    let sessionKey = uuidv4().toUpperCase();
    const sessionId = c.req.param("sessionId");

    return c.json({
      id: sessionId,
      ownerId: uuidv4().replace(/-/gi, ""),
      ownerName: "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
      serverName: "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
      serverAddress: serverAddress || "26.17.156.62",
      serverPort: serverPort || 7777,
      maxPublicPlayers: 220,
      openPublicPlayers: 175,
      maxPrivatePlayers: 0,
      openPrivatePlayers: 0,
      attributes: {
        REGION_s: "NAE",
        GAMEMODE_s: "FORTATHENA",
        ALLOWBROADCASTING_b: true,
        SUBREGION_s: "GB",
        DCID_s: "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
        tenant_s: "Fortnite",
        MATCHMAKINGPOOL_s: "Any",
        STORMSHIELDDEFENSETYPE_i: 0,
        HOTFIXVERSION_i: 0,
        PLAYLISTNAME_s: "Playlist_ShowdownAlt_Solo",
        SESSIONKEY_s: sessionKey,
        TENANT_s: "Fortnite",
        BEACONPORT_i: 15009,
      },
      publicPlayers: [],
      privatePlayers: [],
      totalPlayers: 45,
      allowJoinInProgress: true,
      shouldAdvertise: false,
      isDedicated: false,
      usesStats: false,
      allowInvites: false,
      usesPresence: false,
      allowJoinViaPresence: false,
      allowJoinViaPresenceFriendsOnly: false,
      buildUniqueId: 132345476582,
      lastUpdated: new Date().toISOString(),
      started: false,
    });
  });

  app.post("/fortnite/api/matchmaking/session/*/join", async (c: Context) => {
    c.status(204);
    return c.json([], 200);
  });

  app.post(
    "/fortnite/api/matchmaking/session/matchMakingRequest",
    async (c: Context) => {
      return c.json([]);
    }
  );
}
